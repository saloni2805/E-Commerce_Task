import "./App.css"
import Layout from "./components/layout/Layout"
import MyState from "./context/MyState"
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
} from "react-router-dom"
import Home from "./pages/home/home"
import AllProducts from "./pages/products/AllProducts"

function App() {
  return (
    <>
      <MyState>
        <Router>
          <Routes>
            <Route path="/" element={<Layout></Layout>}>
              <Route index element={<Home />} />
              <Route path="/products" element={<AllProducts />} />
              {/* <Route path="/pricing" element={<Pricing />} />
              <Route path="/blog" element={<Blog />} /> */}
            </Route>
          </Routes>
        </Router>
      </MyState>
    </>
  )
}

export default App
