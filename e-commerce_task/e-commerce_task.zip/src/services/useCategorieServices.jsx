// import React from "react"
// import axios from "axios"

// const useCategorieServices = () => {
//   const getCategories = async () => {
//     await axios.get("https://api.escuelajs.co/api/v1/categories")
//   }

//   return {
//     getCategories,
//   }
// }

// export default useCategorieServices
